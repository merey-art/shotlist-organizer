# 🎬 Shot List Organizer

A full-stack film production tool that helps directors and crews plan their scenes with visual references and organized metadata. Built with **Go (Gin)**, **MySQL**, and **HTML/JS frontend**.

---

## 🚀 Features

- Upload new shots with:
  - Scene name
  - Shot type (Wide, Medium, Close-up)
  - Description
  - Image preview
- View all shots in a visual card layout
- Delete unwanted shots
- Stores data in a **MySQL database**
- RESTful API endpoints

---

## 🛠 Tech Stack

- **Backend:** Go (Gin framework)
- **Database:** MySQL
- **Frontend:** HTML, CSS, Vanilla JavaScript
- **Storage:** Local file system (`/uploads`)

---

## 📂 Project Structure

```
shotlist-organizer/
├── main.go              # Go backend server
├── public/
│   └── index.html       # Frontend HTML UI
├── uploads/             # Folder for uploaded images (runtime only)
└── README.md
```

---

## 📦 API Endpoints

| Method | Endpoint         | Description               |
|--------|------------------|---------------------------|
| GET    | `/`              | Load HTML frontend        |
| GET    | `/shots`         | Get all shots             |
| POST   | `/shots`         | Create a new shot         |
| DELETE | `/shots/:id`     | Delete a shot by ID       |
| POST   | `/upload`        | Upload image only         |
| GET    | `/api`           | API status check          |

---

## 🧰 Setup Instructions

1. **Clone the repo**

2. **Create MySQL database**
   ```sql
   CREATE DATABASE shotlist;
   USE shotlist;
   ```

3. **Create table**
   ```sql
   CREATE TABLE shots (
       id INT AUTO_INCREMENT PRIMARY KEY,
       scene VARCHAR(255) NOT NULL,
       shot_type VARCHAR(100) NOT NULL,
       description TEXT,
       image_url TEXT
   );
   ```

4. **Run the app**
   ```bash
   go run main.go
   ```

5. **Open in browser**
   ```
   http://localhost:8000/
   ```

---

## ✨ Future Improvements

- Edit shot feature
- Tagging or search
- User login/auth
- Cloud image hosting (e.g. S3)
- Mobile-friendly UI

---

## 🧑‍💻 Author

Made with 💙 by [Your Name]
